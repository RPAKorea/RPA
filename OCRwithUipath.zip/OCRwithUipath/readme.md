# OCR with uipath

## imagemagick

**이미지 전처리**는 imagemagick 이라는 오픈소스 프로그램을 사용합니다.

>References
>
>imagemagick 홈페이지 : [https://imagemagick.org/script/index.php](https://imagemagick.org/script/index.php)
>
>imagemagick 다운로드 : [https://imagemagick.org/script/download.php](https://imagemagick.org/script/download.php)
>
> 지원하는 이미지 포맷 : [https://imagemagick.org/script/formats.php](https://imagemagick.org/script/formats.php)

### imagemagick 주로 사용하는 실행 옵션

모든 실행 옵션 목록 : [https://imagemagick.org/script/command-line-options.php](https://imagemagick.org/script/command-line-options.php)

1. 사이즈 보정 resize 옵션
```
magick input.jpg -resize 50% output.png
```
2. 기울기 보정 deskew 옵션
```
magick input.jpg -deskew 40% output.png
```
3. 테두리 보정 border와 bordercolor 옵션
```
magick input.jpg -bordercolor white -border 10x10 output.jpg
```

## tesseract-ocr with uipaht

> References
>
>Tesseract-ocr 홈페이지 : [https://tesseract-ocr.github.io/](https://tesseract-ocr.github.io/)
>
>Tesseract github : [https://github.com/tesseract-ocr/tesseract](https://github.com/tesseract-ocr/tesseract)
>
>Tesseract Download : [https://github.com/UB-Mannheim/tesseract/wiki](https://github.com/UB-Mannheim/tesseract/wiki)

  - ubuntu에는 Tesseract-Ocr이 기본으로 설치 되어있습니다.
  - 윈도우 시스템에는 5.0이상 사용하는 것을 권장하고 있습니다.
  - 설치 후, 실행 파일이 있는 디렉터리 경로를 Path 환경변수에 추가해야 합니다.

### [_성능 향상_](https://tesseract-ocr.github.io/tessdoc/ImproveQuality.html) 시키기

#### 이미지 색 반전
하얀 바탕의 검은 글씨로 된 문서나, 검은 바탕의 하얀 글씨로 된 문서나 모두 잘 인식한다고 합니다.(하얀바탕만 해봐서 모름)


**문서 형태는 모두 동일** 해야 합니다. 또한 **볼드체도 있으면 안됍니다.**깨끗한 용지만 사용하고 커피자국, 메모 다 안됍니다. 글자 좌우 너비가 같은 **monospace font**가 최적의 효율을 냅니다.

#### 스캔 설정
반드시 **사진기가 아닌 스캐너**로 스캔 설정 300dpi로 문서를 스캔해야 합니다.
![binarisation](https://tesseract-ocr.github.io/tessdoc/images/binarisation.png)
왜냐하면 Tesseract 내부에서 위와 같이 binarisation을 진행 하는데 이미지에 그림자가 진다면 글자와 배경을 구분 하기 어려워 집니다.

#### 글자 크기 보정
[실험](https://groups.google.com/g/tesseract-ocr/c/Wdh_JJwnw94/m/24JHDYQbBQAJ)에 따르면 **글자의 크기는 30~33pixels** 크기여야합니다.
![sizeExperiment](https://groups.google.com/group/tesseract-ocr/attach/51b840d4782db/tess4_error_rate.png?part=0.2&view=1)

#### 기울기 보정
기울기가 비뚤어진 사진도 **기울기를 보정**해야합니다.
![deskew](https://tesseract-ocr.github.io/tessdoc/images/skew-linedetection.png)
imagemagick을 이용하여 기울기를 보정합니다.

#### border
**Borders**가 하얀색이 아니라 다른 색이면 가끔 Border를 다른 글자로 인식합니다. 또한 Border는 최소한 10x10pt 는 되어야 인식률이 좋습니다. imagemagick을 이용하여 border를 보정합니다.

#### 페이지 분할

실행 옵션중에 `--psm -N` 옵션으로 이미지의 형태를 정해 줄 수 있습니다.
```
0 = Orientation and script detection (OSD) only.
1 = Automatic page segmentation with OSD.
2 = Automatic page segmentation, but no OSD, or OCR. (not implemented)
3 = Fully automatic page segmentation, but no OSD. (Default)
4 = Assume a single column of text of variable sizes.
5 = Assume a single uniform block of vertically aligned text.
6 = Assume a single uniform block of text.
7 = Treat the image as a single text line.
8 = Treat the image as a single word.
9 = Treat the image as a single word in a circle.
10 = Treat the image as a single character.
11 = Sparse text. Find as much text as possible in no particular order.
12 = Sparse text with OSD.
13 = Raw line. Treat the image as a single text line,
     bypassing hacks that are Tesseract-specific.
```

#### Dictionaries, word lists, and patterns
Tesseract는 글자로 이루어진 문장을 인식하도록 설계 되었습니다. 다른 형태의 문서를 인식하려면 전처리를 많이 거쳐야합니다.

실행 옵션으로 `tessedit_char_whitelist`를 설정하여 인식하는 문자의 종류를 제한 할 수있습니다.(LSTM 5.0버전 부터 가능)

표 형태는 인식률이 저조합니다.

### 명령어 메뉴얼
> References : [https://github.com/tesseract-ocr/tesseract/blob/master/doc/tesseract.1.asc](https://github.com/tesseract-ocr/tesseract/blob/master/doc/tesseract.1.asc)

### 지원 언어
[https://github.com/tesseract-ocr/tesseract/blob/master/doc/tesseract.1.asc#languages-and-scripts](https://github.com/tesseract-ocr/tesseract/blob/master/doc/tesseract.1.asc#languages-and-scripts)

### ocr 대상
![ocr대상](sampleData/2019w2.png)


![ocr 구역](sampleData/w2ReadArea.JPG)

노란 부분만 읽을 겁니다.

### Powershell 설정 확인

Powershell 스크립트가 핵심인데, powershell script를 정상적으로 실행 할 수 있도록 설정 해야 합니다. [ExecutionPolicy종류](https://docs.microsoft.com/en-us/powershell/module/microsoft.powershell.core/about/about_execution_policies?view=powershell-7.1)

ExecutionPolicy 설정
```
Set-ExecutionPolicy -ExecutionPolicy Unrestricted -Scope CurrentUser
```

ExecutionPolicy 설정 확인
```
Get-ExecutionPolicy -list
```

### 폴더 구성

- RPA
  - WageAndTax
    - Data
      - ScanImage
        - 이미지1파일
        - 이미지2파일...
      - Script
        - TesseractOCR.ps1
    - Result
      - 이미지1폴더
        - 이미지1보정파일
        - CROP
          - cropImage1
          - cropImage2
          - cropImage3...
        - OcrResult
          - OcrResultTxt1
          - OcrResultTxt2
          - OcrResultTxt3...
      - 이미지2
        - 이미지2보정파일
        - CROP
          - cropImage1
          - cropImage2
          - cropImage3...
        - OcrResult
          - OcrResultTxt1
          - OcrResultTxt2
          - OcrResultTxt3...
      - OCRResult.xlsx

### FlowChart
![flowchart](images/WageAndTax/flowchart1.JPG)
![flowchart](images/WageAndTax/flowchart2.JPG)
![flowchart](images/WageAndTax/flowchart3.JPG)

### 파일명 추출 invoke code

```
out_Str_FullPaths = Directory.GetFiles(in_Str_DataPath);
out_Str_FileNames = new string[out_Str_FullPaths.Length];

for(int i = 0; i < out_Str_FullPaths.Length; i++){
	string[] PathSplit = out_Str_FullPaths[i].Split('\\');
	out_Str_FileNames[i] = PathSplit[PathSplit.Length-1];
}
```

### powershell script

[스크립트 링크](RPA/WageAndTax/Data/Script/TesseactOCR.ps1)

crop 할때
```
magick $DeskewedFilePath -crop 234x27+440+96 -bordercolor white -border 10x10 $SSNimagePath
```

-crop "cropingarea" 와 같은 형식으로cropingarea를 하드 코딩 해주어야 한다.

이때 그림판을 이용하면 간편하다

![그림판](images/WageAndTax/croping.JPG)

왼쪽 아래에 그림판에서 사각형으로 선택한 부분의 px정보가 나온다.

### 결과

![엑셀](images/WageAndTax/result.JPG)

ocr 결과 중, x 체크 항목이 공란인 경우 특수 문자가 나온다.

또한 가격 정보중에 소수점이 두개씩 붙어 있는데 이는 프로그램으로 ','를 제외 했기 때문이다.
','와 '.'는 OCR로 구분이 힘들다.

이 부분은 나중에 사용할때 데이터 가공을 또다시 해주어야 한다.

','의 경우 사람이 3자리씩 끊어서 보기 쉽게 하려는 것이기 때문에 데이터 가공 작업을 하기 보다는 현업과 협의 후 ','를 쓰지 않도록 하는 것이 좋다.

## Modi with Uipath

[Microsoft Office Document Image](https://support.microsoft.com/en-us/topic/install-modi-for-use-with-microsoft-office-2010-4fbd3076-6d01-9cb7-c574-3bbabc9eead9)는 SharePoint Designer 2007까지 제품 구성요소중 선택하서 설치, 사용할 수 있었다. 하지만 현재 Sharepoint Designer 2007 공식 다운로드 페이지도 존재하지 않으며, Modi또한 더 이상 추가 개발, 개선이 이루어 지고 있지 않다. 대중의 관심도 낮아서 관련 자료가 없다.


## Microsoft Project Oxford Online OCR

2019.10.1 버전부터 더이상 사용되지 않습니다.(deprecated)
[https://docs.uipath.com/activities/docs/microsoft-cloud-ocr](https://docs.uipath.com/activities/docs/microsoft-cloud-ocr)

## Microsoft Azure Computer Vision OCR

[가격정책](https://azure.microsoft.com/en-us/pricing/details/cognitive-services/computer-vision/)

[OCR 사용 설명](https://docs.microsoft.com/ko-kr/azure/cognitive-services/computer-vision/concept-recognizing-text)

설명서에 따르면 특별한 전처리는 필요 없는듯 하다.(기울기 보정, cropping...)

하지만 이미지 선명도의 영향을 안받을 수 는 없으니 300dpi 스캔 이미지를 사용하는 것을 추천한다.

![readapi](images/WageAndTax/UseReadAPI.JPG)

Microsoft Azure Computer vision API는 두가지 종류가 있다.

하나는 OCR API, 다른 하나는 Read API인데 Read API가 최신 API이며 성능또한 뛰어나다

[OCR예시](RPA/VisionAPITest/Result/Azure/Origin/2019w2)

실행 결과 text는 제대로 변환이 되었지만, 문장별로 개행이 뒤죽 박죽이다. 따라서 원하는 부분을 Crop하여 각각 OCR을 실행하거나 통쨰로 실행 후 복잡한 파싱을 거쳐야 한다.

## Google Cloud Vision

[가격정책](https://cloud.google.com/vision/pricing)

[지원언어](https://cloud.google.com/vision/docs/languages)

[사전 설정](https://cloud.google.com/vision/docs/before-you-begin)

[사용법](https://cloud.google.com/vision/docs/ocr)

[실행 예](RPA/VisionAPITest/Result/Google/Origin/2019w2)


## Uipath Document OCR

[endpoint 정보, pricing 정보](https://docs.uipath.com/automation-cloud/docs/about-licensing#document-understanding-endpoints)
중간에 'Document Understanding Endpoints'가 조그맣게 있는데 잘 찾아야 보입니다.

![uipath document ocr license key 위치](images/WageAndTax/UipathDocumentOCRapikey.JPG)
api 키 위치


[실행 예](RPA/VisionAPITest/Result/Uipath/Origin/2019w2)

## Document Understanding

[공식소개](https://www.uipath.com/blog/introducing-document-understanding-process-documents-intelligently)

[포럼 글](https://forum.uipath.com/t/du-ocr-ocr/269473)

abby 제품중의 두가지가 있는거다

flash 캡처 텍스트 추출 양식을 정한다.

fine 리더 모든 텍스트를 추출하여 원하는 파일 포맷으로 출력

aa는 iq봇 쓴다.

인식률에 대한 기준이 명확하지 않음.
