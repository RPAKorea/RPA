<#�̹��� ���ϵ� ��������#>
$ScanedFiles = Get-ChildItem .\RPA\WageAndTax\Data\Scanimage
$ScanedFiles
#�� ���ϸ��� ó��
for($i = 0; $i -lt $ScanedFiles.Count; $i++){
    #���丮 ����
    $ScanFileName = $ScanedFiles[$i].Name
    $CROPPath = ".\RPA\WageAndTax\Result\$($ScanFileName.Substring(0, $ScanFileName.Length-4))\CROP"
    $OcrResultPath = ".\RPA\WageAndTax\Result\$($ScanFileName.Substring(0, $ScanFileName.Length-4))\OcrResult"

    New-Item -ItemType Directory -Force $CROPPath
    New-Item -ItemType Directory -Force $OcrResultPath

    #����, ũ�� ����
    $DeskewedFilePath =  ".\RPA\WageAndTax\Result\$($ScanFileName.Substring(0, $ScanFileName.Length-4))\$($ScanFileName)"
    magick $ScanedFiles[$i].FullName -deskew 40% -resize 200% $DeskewedFilePath 

    #a. SocialSecurityNumber �ڸ���
    $SSNimagePath = "$($CROPPath)\SSN.png"
    magick $DeskewedFilePath -crop 234x27+440+96 -bordercolor white -border 10x10 $SSNimagePath 

    #a. SocialSecurityNumber Tesseract-OCR ���� single text line�� psm 7
    Tesseract $SSNimagePath "$($OcrResultPath)\a" --psm 7 --dpi 300 -c tessedit_char_whitelist=1234567890- --oem 1 

    #c. Name, Address, ZIP code �ڸ���
    $NAZimagePath = "$($CROPPath)\NAS.png"
    magick $DeskewedFilePath -crop 743x139+140+225 -bordercolor white -border 10x10 $NAZimagePath

    #c. Name, Address, ZIP code Tesseract-OCR ���� single uniform block�� psm 6 
    Tesseract $NAZimagePath "$($OcrResultPath)\c" --psm 6 --dpi 300 --oem 1

    #1.Wage, tips, other compensation �ڸ���
    $WToCimagePath = "$($CROPPath)\1_WToC.png"
    magick $DeskewedFilePath -crop 300x30+914+156 -bordercolor white -border 10x10 $WToCimagePath 

    #1.Wage, tips, other compensation Tesseract-OCR ���� single text line�� psm 7
    Tesseract $WToCimagePath "$($OcrResultPath)\1" --psm 7 --dpi 300 -c tessedit_char_whitelist=1234567890. --oem 1 

    #2.Federal income tax witheld �ڸ���
    $FiTimagePath = "$($CROPPath)\2_FiT.png"
    magick $DeskewedFilePath -crop 300x30+1239+155 -bordercolor white -border 10x10 $FiTimagePath

    #2.Federal income tax witheld Tesseract-OCR ���� single text line�� psm 7
    Tesseract $FiTimagePath "$($OcrResultPath)\2" --psm 7 --dpi 300 -c tessedit_char_whitelist=1234567890. --oem 1 

    #3.Social Security Wage �ڸ���
    $SSWimagePath = "$($CROPPath)\3_SSW.png"
    magick $DeskewedFilePath -crop 300x30+917+221 -bordercolor white -border 10x10 $SSWimagePath

    #3.Social Security Wage  Tesseract-OCR ���� single text line�� psm 7
    Tesseract $SSWimagePath "$($OcrResultPath)\3" --psm 7 --dpi 300 -c tessedit_char_whitelist=1234567890. --oem 1 

    #4.Social Security Tax �ڸ���
    $SSTimagePath = "$($CROPPath)\4_SST.png"
    magick $DeskewedFilePath -crop 300x30+1240+220 -bordercolor white -border 10x10 $SSTimagePath

    #4.Social Security Tax  Tesseract-OCR ���� single text line�� psm 7
    Tesseract $SSTimagePath "$($OcrResultPath)\4" --psm 7 --dpi 300 -c tessedit_char_whitelist=1234567890. --oem 1 

    #5.Medicate Wages and Tax �ڸ���
    $MWTimagePath = "$($CROPPath)\5_MWT.png"
    magick $DeskewedFilePath -crop 300x35+916+285 -bordercolor white -border 10x10 $MWTimagePath

    #5.Medicare Wages and Tax Tesseract-OCR ���� single text line�� psm 7
    Tesseract $MWTimagePath "$($OcrResultPath)\5" --psm 7 --dpi 300 -c tessedit_char_whitelist=1234567890. --oem 1 

    #6.Medicare Tax Witheld �ڸ���
    $MTWimagePath = "$($CROPPath)\6_MTW.png"
    magick $DeskewedFilePath -crop 295x35+1238+285 -bordercolor white -border 10x10 $MTWimagePath

    #6.Medicare Tax Withel Tesseract-OCR ���� single text line�� psm 7
    Tesseract $MTWimagePath "$($OcrResultPath)\6" --psm 7 --dpi 300 -c tessedit_char_whitelist=1234567890. --oem 1 

    #13_1. Statutory Employee �ڸ���
    $SEimagePath = "$($CROPPath)\13_1_SE.png"
    magick $DeskewedFilePath -crop 20x20+954+547 -bordercolor white -border 10x10 $SEimagePath

    #13_1. Statutory Employee Tesseract-OCR ���� single charactor�� psm 10
    Tesseract $SEimagePath "$($OcrResultPath)\13_1" --psm 10 --dpi 300 -c tessedit_char_whitelist=X --oem 1

    #13_2. Restorant plan �ڸ���
    $RPimagePath = "$($CROPPath)\13_2_RP.png"
    magick $DeskewedFilePath -crop 20x20+1047+546 -bordercolor white -border 10x10 $RPimagePath

    #13_2. Restorant plan Tesseract-OCR ���� single charactor�� psm 10
    Tesseract $RPimagePath "$($OcrResultPath)\13_2" --psm 10 --dpi 300 -c tessedit_char_whitelist=X --oem 1

    #13_3.Third Party �ڸ���
    $TPimagePath = "$($CROPPath)\13_3_TP.png"
    magick $DeskewedFilePath -crop 20x20+1142+547 -bordercolor white -border 10x10 $TPimagePath

    #13_3.Third Party Tesseract-OCR ���� single charactor�� psm 10
    Tesseract $TPimagePath "$($OcrResultPath)\13_3" --psm 10 --dpi 300 -c tessedit_char_whitelist=X --oem 1

    #16. State Wages Tips �ڸ���
    $SWTimagePath = "$($CROPPath)\16_SWT.png"
    magick $DeskewedFilePath -crop 209x34+555+755 -bordercolor white -border 10x10 $SWTimagePath

    #16. State Wages Tips Tesseract-OCR ���� single text line�� psm 7
    Tesseract $SWTimagePath "$($OcrResultPath)\16" --psm 7 --dpi 300 -c tessedit_char_whitelist=1234567890. --oem 1

    #17. State income Tax �ڸ���
    $SiTimagePath = "$($CROPPath)\17_SiT.png"
    magick $DeskewedFilePath -crop 188x32+782+756 -bordercolor white -border 10x10 $SiTimagePath

    #17. State income Tax Tesseract-OCR ���� single text line�� psm 7
    Tesseract $SiTimagePath "$($OcrResultPath)\17" --psm 7 --dpi 300 -c tessedit_char_whitelist=1234567890. --oem 1

    #18. Local Wages tips �ڸ���
    $LWTimagePath = "$($CROPPath)\18_LWT.png"
    magick $DeskewedFilePath -crop 206x34+991+755 -bordercolor white -border 10x10 $LWTimagePath

    #18. Local Wages tips Tesseract-OCR ���� single text line�� psm 7
    Tesseract $LWTimagePath "$($OcrResultPath)\18" --psm 7 --dpi 300 -c tessedit_char_whitelist=1234567890. --oem 1

    #19. Local income Tax �ڸ���
    $LiTimagePath = "$($CROPPath)\19_LiT.png"
    magick $DeskewedFilePath -crop 192x34+1215+755 -bordercolor white -border 10x10 $LiTimagePath

    #19. Local income Tax Tesseract-OCR ���� single text line�� psm 7
    Tesseract $LiTimagePath "$($OcrResultPath)\19" --psm 7 --dpi 300 -c tessedit_char_whitelist=1234567890. --oem 1

    #Form Type �ڸ���
    $FTimagePath = "$($CROPPath)\FT.png"
    magick $DeskewedFilePath -crop 118x55+180+869 -resize 61% -bordercolor white -border 10x10 $FTimagePath

    #Form Type Tesseract-OCR ���� single text line�� psm 7
    Tesseract $FTimagePath "$($OcrResultPath)\FT" --psm 7 --dpi 300 --oem 1

    #Year �ڸ���
    $YearimagePath = "$($CROPPath)\Year.png"
    magick $DeskewedFilePath -crop 181x61+791+870 -resize 61% -bordercolor white -border 10x10 $YearimagePath

    #Year Tesseract-OCR ���� single text line�� psm 7
    Tesseract $YearimagePath "$($OcrResultPath)\Year" --psm 7 --dpi 300 -c tessedit_char_whitelist=1234567890 --oem 1

    <#OCRresult txt������ LF ����#>
    $OcrFiles = Get-ChildItem $OcrResultPath
    for($j = 0; $j -lt $OcrFiles.Length; $j++){
        $OcrFiles[$j]
        $FileContent = type $OcrFiles[$j].FullName
        $FileContent
        $FileContent | select -SkipLast 1 | Set-Content $OcrFiles[$j].FullName -Force
    }
}